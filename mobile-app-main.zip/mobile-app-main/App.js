import React from 'react';
import Navigation from './navigation/navigation';

const App = () => {
  return (
    <Navigation/>
  );
}

export default App;
